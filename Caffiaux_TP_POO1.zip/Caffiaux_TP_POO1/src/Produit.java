public class Produit {
    private int produit;
    private String nom;
    private double quantite;
    private double prixuni;
    private int stock;
    //construteur

    public Produit(int produit, String nom, double quantite, double prixuni, int stock) {
        this.produit = produit;
        this.nom = nom;
        this.quantite = quantite;
        this.prixuni = prixuni;
        this.stock = stock;
    }
    public int getProduit() {
        return produit;
    }
    public void setProduit(int produit) {
        this.produit = produit;
    }
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public double getQuantite() {
        return quantite;
    }
    public void setQuantite(double quantite) {
        this.quantite = quantite;
    }
    public double getPrixuni() {
        return prixuni;
    }
    public void setPrixuni(double prixuni) {
        this.prixuni = prixuni;
    }
    public int getStock() {
        return stock;
    }
    public void setStock(int stock) {
        this.stock = stock;
    }
    public boolean Alerte (){
        if(this.quantite<=this.stock)
            return true;
        else;
        return false;
    }
}

