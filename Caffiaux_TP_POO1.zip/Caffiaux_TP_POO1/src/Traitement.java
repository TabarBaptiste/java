import java.sql.SQLOutput;
import java.util.ArrayList;
public class Traitement {
    public static void mane (String[]args){
 //liste
    ArrayList<Produit> listeproduit = new ArrayList<Produit>();
    Produit produ = new Produit(5,"cils",155,30,25);
    listeproduit.add(produ);

        System.out.println("si stock de sécurite atteint? "+produ.Alerte());
    }

}
